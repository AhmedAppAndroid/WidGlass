# GlassFlow — Liquid Glass Dashboard

A free, responsive widget dashboard with a translucent Liquid Glass look.

## Included
- Dark and light themes (saved locally)
- Live local clock and calendar
- Quick notes saved in the browser on this device
- Focus timer with 25 / 15 / 5 minute presets
- Daily thought widget
- Show / hide widgets
- Basic offline app-shell caching (PWA service worker)
- GitHub Actions deployment to GitHub Pages

## Run locally
Open `index.html` in a browser. For service-worker/offline testing, serve the folder through a local static server.

## Publish with GitHub Pages
1. Create a new GitHub repository, for example `glassflow`.
2. Upload all files and folders from this project to the repository.
3. Make sure the default branch is named `main`.
4. In GitHub, open **Settings → Pages** and choose **GitHub Actions** as the build and deployment source.
5. Push to `main`, or open **Actions** and run **Deploy GlassFlow to GitHub Pages** manually.
6. When the workflow finishes, open the Pages URL shown in the deployment job.

## Free by design
This starter app contains no payment flow, subscriptions, premium lock, or in-app purchases.
Notes and preferences stay in the browser's local storage; they are not synced between devices.

## Customization
- Edit `styles.css` to change the glass, blur, colors, spacing, and responsive layout.
- Edit `index.html` to add or rearrange widgets.
- Edit `app.js` to add widget behavior.
