(() => {
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const root = document.documentElement;
  const STORAGE = { theme: "glassflow-theme", notes: "glassflow-notes", widgets: "glassflow-widgets" };

  // Theme
  const savedTheme = localStorage.getItem(STORAGE.theme);
  if (savedTheme === "light" || savedTheme === "dark") root.dataset.theme = savedTheme;
  $("#themeToggle").addEventListener("click", () => {
    root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark";
    localStorage.setItem(STORAGE.theme, root.dataset.theme);
    toast(`${root.dataset.theme === "dark" ? "Dark" : "Light"} theme enabled`);
  });

  // Live clock and date
  const timeFmt = new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit", hour12: true });
  const dayFmt = new Intl.DateTimeFormat(undefined, { weekday: "long" });
  const dateFmt = new Intl.DateTimeFormat(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
  function updateClock() {
    const now = new Date();
    const parts = timeFmt.formatToParts(now);
    const hourMinute = parts.filter(p => p.type === "hour" || p.type === "minute").map(p => p.value).join(":");
    const period = parts.find(p => p.type === "dayPeriod")?.value || "";
    $("#clockTime").innerHTML = `${hourMinute}<span>${period}</span>`;
    $("#clockDay").textContent = dayFmt.format(now);
    $("#clockZone").textContent = Intl.DateTimeFormat().resolvedOptions().timeZone.split("/").pop().replaceAll("_", " ").toUpperCase();
    $("#todayLabel").textContent = "Today";
    $("#fullDate").textContent = dateFmt.format(now);
  }
  updateClock();
  setInterval(updateClock, 1000);

  // Monthly calendar
  function renderCalendar() {
    const now = new Date(), year = now.getFullYear(), month = now.getMonth();
    $("#calendarMonth").textContent = new Intl.DateTimeFormat(undefined, { month: "long", year: "numeric" }).format(now);
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevDays = new Date(year, month, 0).getDate();
    const cells = [];
    for (let i = 0; i < 42; i++) {
      let day, outside = false;
      if (i < firstDay) { day = prevDays - firstDay + i + 1; outside = true; }
      else if (i >= firstDay + daysInMonth) { day = i - firstDay - daysInMonth + 1; outside = true; }
      else day = i - firstDay + 1;
      const isToday = !outside && day === now.getDate();
      cells.push(`<span class="${outside ? "outside" : ""} ${isToday ? "today" : ""}">${day}</span>`);
    }
    $("#calendarDays").innerHTML = cells.join("");
    $("#calendarFoot").textContent = `Today · ${now.getDate()} ${new Intl.DateTimeFormat(undefined, { month: "short" }).format(now)}`;
  }
  renderCalendar();

  // Notes saved locally on this device
  const notes = $("#notesInput");
  notes.value = localStorage.getItem(STORAGE.notes) || "";
  function updateNoteCount() { $("#notesCount").textContent = `${notes.value.length} / 1200`; }
  updateNoteCount();
  notes.addEventListener("input", () => {
    localStorage.setItem(STORAGE.notes, notes.value);
    updateNoteCount();
    $("#savedLabel").textContent = "Notes saved";
  });

  // Focus timer
  let duration = 25 * 60, remaining = duration, interval = null;
  const circumference = 2 * Math.PI * 69;
  const ring = $("#ringProgress");
  ring.style.strokeDasharray = circumference;
  function paintTimer() {
    const minutes = Math.floor(remaining / 60).toString().padStart(2, "0");
    const seconds = (remaining % 60).toString().padStart(2, "0");
    $("#timerValue").textContent = `${minutes}:${seconds}`;
    ring.style.strokeDashoffset = circumference * (1 - remaining / duration);
  }
  function stopTimer() { if (interval) clearInterval(interval); interval = null; }
  $("#timerStart").addEventListener("click", () => {
    if (interval) {
      stopTimer(); $("#timerStart").textContent = "Resume focus"; $("#focusStatus").textContent = "Paused. Take a breath.";
      return;
    }
    if (remaining <= 0) remaining = duration;
    $("#timerStart").textContent = "Pause session";
    $("#focusStatus").textContent = "You're in your focus zone.";
    interval = setInterval(() => {
      remaining--;
      paintTimer();
      if (remaining <= 0) {
        stopTimer(); $("#timerStart").textContent = "Start again"; $("#focusStatus").textContent = "Session complete. Well done!";
        toast("Focus session complete — nice work!");
      }
    }, 1000);
  });
  $("#timerReset").addEventListener("click", () => {
    stopTimer(); remaining = duration; paintTimer();
    $("#timerStart").textContent = "Start focus"; $("#focusStatus").textContent = "Make space to focus.";
  });
  $$(".preset").forEach(button => button.addEventListener("click", () => {
    stopTimer(); duration = Number(button.dataset.minutes) * 60; remaining = duration; paintTimer();
    $$(".preset").forEach(b => b.classList.toggle("active", b === button));
    $("#timerStart").textContent = "Start focus"; $("#focusStatus").textContent = "Make space to focus.";
  }));
  paintTimer();

  // Daily thoughts
  const thoughts = [
    ["Small steps still move you forward.", "A gentle reminder"],
    ["You don't have to do everything. Just the next thing.", "One moment at a time"],
    ["Progress is built in the quiet moments you keep showing up.", "Keep going"],
    ["Make room for what matters, and let the rest wait.", "A little perspective"],
    ["Done with care is better than perfect someday.", "Start where you are"],
    ["Give your attention to the things you can grow.", "Today's intention"]
  ];
  let lastThought = -1;
  function newThought() {
    let index = Math.floor(Math.random() * thoughts.length);
    if (thoughts.length > 1 && index === lastThought) index = (index + 1) % thoughts.length;
    lastThought = index;
    $("#quoteText").textContent = thoughts[index][0];
    $("#quoteAuthor").textContent = thoughts[index][1];
  }
  newThought();
  $("#newQuote").addEventListener("click", newThought);

  // Widget visibility controls
  const widgetInputs = $$("[data-toggle-widget]");
  const savedWidgets = JSON.parse(localStorage.getItem(STORAGE.widgets) || "null");
  function applyWidgets(state) {
    widgetInputs.forEach(input => {
      const key = input.dataset.toggleWidget;
      const visible = state ? state[key] !== false : input.checked;
      input.checked = visible;
      const card = document.querySelector(`[data-widget="${key}"]`);
      if (card) card.hidden = !visible;
    });
    const count = widgetInputs.filter(input => input.checked).length;
    $("#widgetCount").textContent = `${count} widget${count === 1 ? "" : "s"}`;
  }
  if (savedWidgets) applyWidgets(savedWidgets); else applyWidgets(null);
  function saveWidgets() {
    const state = Object.fromEntries(widgetInputs.map(input => [input.dataset.toggleWidget, input.checked]));
    localStorage.setItem(STORAGE.widgets, JSON.stringify(state));
    applyWidgets(state);
  }
  widgetInputs.forEach(input => input.addEventListener("change", saveWidgets));
  $("#resetWidgets").addEventListener("click", () => {
    widgetInputs.forEach(input => input.checked = true);
    saveWidgets(); toast("All widgets restored");
  });
  $("#manageButton").addEventListener("click", () => {
    const menu = $("#widgetMenu"), opening = menu.hidden;
    menu.hidden = !opening;
    $("#manageButton").setAttribute("aria-expanded", String(opening));
  });
  document.addEventListener("click", event => {
    if (!event.target.closest(".manage-wrap")) {
      $("#widgetMenu").hidden = true;
      $("#manageButton").setAttribute("aria-expanded", "false");
    }
  });

  let toastTimer;
  function toast(message) {
    const node = $("#toast"); node.textContent = message; node.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => node.classList.remove("show"), 2300);
  }

  // Offline app shell
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
  }
})();
